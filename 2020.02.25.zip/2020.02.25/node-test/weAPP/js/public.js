// var SweetFun = function() {
//   return {
//     userNameNull: function() {
//       swal("用户名为空 !", "请刷新后，重新输入！");
//     },
//     codeNull: function() {
//       swal({
//         title: "验证码为空 !",
//         text: "请刷新后，重新输入！",
//         imageUrl: 'img/warning.png'
//       });
//     },
//     psdIsNull: function() {
//       swal({
//         title: "密码输入为空 !",
//         text: "请刷新后，重新输入！",
//         imageUrl: 'img/warning.png'
//       });
//     },
//     twoPsdDiffer: function() {
//       swal("密码两次输入不一致 !", "", "error")
//     },
//     resetPsdSuc: function() {
//       swal("重置密码成功！", "", "success")
//     },
//     PsdSixNum: function() {
//       swal("密码输入格式应为6位数字 !", "请刷新后，重新输入！");
//     },
//     resetPayPsdSuc: function() {
//       // swal("重置支付密码成功！", "", "success")
//       swal({
//         title: "重置支付密码成功！",
//         text: "",
//         type: "success",
//         showCancelButton: true,
//         confirmButtonColor: '#DD6B55',
//         confirmButtonText: '确认',
//         cancelButtonText: "取消",
//         closeOnConfirm: false,
//         closeOnCancel: false
//       },
//       function(isConfirm){

//         if (isConfirm){
//           swal("设置成功 !", "你的支付密码已经修改 !", "success", "4000");
//           location.href="security.html";
//         } else {
//           swal("取消", "你已经取消了操作", "error");
//         }
//       });
//     },
//     Msg: function() {
//       swal({
//         title: "emsg...",
//         text: "2秒后自动关闭...",
//         timer: 2000
//       });
//     },
//     paySuc: function() {
//       swal({
//         title: "支付成功 !",
//         text: "2秒后自动关闭...",
//         imageUrl: 'img/right.png',
//         timer: 2000
//       });
//     },
//     payPsdSetSuc: function() {
//       swal({
//         title: "支付密码设置成功 !",
//         text: "2秒后自动关闭...",
//         imageUrl: 'img/right.png',
//         timer: 2000
//       });
//     },
//     PsdError: function() {
//       swal({
//         title: "两次输入密码不一致 !",
//         text: "2秒后自动关闭...",
//         imageUrl: 'img/error.png',
//         timer: 2000
//       });
//     },
//     NameNotNull: function() {
//       swal("姓名不能为空 !", "请刷新后，重新输入！");
//     },
//     IdNumberNotNull: function() {
//       swal("证件号码不能为空 !", "请刷新后，重新输入！");
//     },
//     UploadIdNumber: function() {
//       swal("请上传证件照 !", "请刷新后，重新输入！");
//     },
//     UploadSuc: function() {
//       swal({
//         title: "上传成功 !",
//         text: "2秒后自动关闭...",
//         imageUrl: 'img/right.png',
//         timer: 2000
//       });
//     },
//     phoneNumberNull: function() {
//       swal({
//         title: "手机号为空 !",
//         text: "请刷新后，重新输入！",
//         imageUrl: 'img/warning.png'
//       });
//     },
//     nickNameNull: function() {
//       swal({
//         title: "昵称为空 !",
//         text: "请刷新后，重新输入！",
//         imageUrl: 'img/warning.png'
//       });
//     },
//     agreeMent: function() {
//       swal({
//         title: "请仔细阅读并同意协议 !",
//         text: "请勾选用户协议",
//         imageUrl: 'img/warning.png'
//       });
//     },
//     payAgainSetSuc: function() {
//       swal({
//         title: "支付密码重新设置成功 !",
//         text: "2秒后自动关闭...",
//         imageUrl: 'img/right.png',
//         timer: 2000
//       });
//     },
//   }
// };
// var SweetFunObj = new SweetFun();



var M = {};
var SweetFun = function() {
  return {
    userNameNull: function() {
      M.dialog = jqueryAlert({
        'content' : '用户名为空 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    codeNull: function() {
      M.dialog = jqueryAlert({
        'icon'    : 'img/warning.png',
        'content' : '验证码为空 !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
    psdIsNull: function() {
      M.dialog = jqueryAlert({
        'icon'    : 'img/warning.png',
        'content' : '密码输入为空 !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
    twoPsdDiffer: function() {
      M.dialog = jqueryAlert({
        'content' : '密码两次输入不一致 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    resetPsdSuc: function() {
      M.dialog3 = jqueryAlert({
        'title'   : '提示',
        'content' : '重置密码成功 ！',
        'modal'   : true,
        'end': '',
        'buttons' :{
          '关闭' : function() {
            M.dialog3.destroy();
          },
          '确定' : function() {
            if(M.dialog31){
              return M.dialog31.show();
            }
            M.dialog31 = jqueryAlert({
              'content' : '返回上一层中...'
            })
            location.href="security.html";
            M.dialog31.destroy();
          }
        }
      })
    },
    PsdSixNum: function() {
      M.dialog2 = jqueryAlert({
        'content' : '密码输入格式应为6位数字 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog2.destroy();
          }
        }
      })
    },
    resetPayPsdSuc: function() {
      M.dialog3 = jqueryAlert({
        'title'   : '提示',
        'content' : '重置支付密码成功！',
        'modal'   : true,
        'end': '',
        'buttons' :{
          '关闭' : function() {
            M.dialog3.destroy();
          },
          '确定' : function() {
            if(M.dialog31){
              return M.dialog31.show();
            }
            M.dialog31 = jqueryAlert({
              'content' : '返回上一层中...'
            })
            location.href="security.html";
            M.dialog31.destroy();
          }
        }
      })
    },
    Msg: function() {
      M.dialog = jqueryAlert({
        'content' : 'emsg... !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
    paySuc: function() {
      M.dialog = jqueryAlert({
        'icon'    : 'img/right.png',
        'content' : '支付成功 !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
    payPsdSetSuc: function() {
      M.dialog = jqueryAlert({
        'icon'    : 'img/right.png',
        'content' : '支付密码设置成功 !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
    PsdError: function() {
      M.dialog = jqueryAlert({
        'icon'    : 'img/error.png',
        'content' : '两次输入密码不一致 !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
    NameNotNull: function() {
      M.dialog = jqueryAlert({
        'content' : '姓名不能为空 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    IdNumberNotNull: function() {
      M.dialog = jqueryAlert({
        'content' : '证件号码不能为空 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    UploadIdNumber: function() {
      M.dialog = jqueryAlert({
        'content' : '请上传证件照 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    UploadSuc: function() {
      M.dialog = jqueryAlert({
        'icon'    : 'img/right.png',
        'content' : '上传成功 !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
    phoneNumberNull: function() {
      M.dialog = jqueryAlert({
        'content' : '手机号为空 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    nickNameNull: function() {
      M.dialog = jqueryAlert({
        'content' : '昵称为空 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    agreeMent: function() {
      M.dialog = jqueryAlert({
        'content' : '请仔细阅读并同意协议 !',
        'modal'   : true,
        'end':function(){
          console.log('已关闭弹框')
        },
        'buttons' :{
          '确定' : function() {
            M.dialog.destroy();
          }
        }
      })
    },
    payAgainSetSuc: function() {
      M.dialog = jqueryAlert({
        'icon'    : 'img/right.png',
        'content' : '支付密码重新设置成功 !',
        'closeTime' : 2000,
        'end':function(){
          M.dialog.destroy();
        }
      })
    },
  }
}
var SweetFunObj = new SweetFun();
