const serverURL = "http://192.168.1.121:8888";

// 全局加载时，请先引入loading.js 
function loading1() {
  $('body').loading({
    loadingWidth:240,
    title:'请稍等!',
    name:'test',
    discription:'加载中 . . . .',
    direction:'column',
    type:'origin',
    // originBg:'#71EA71',
    originDivWidth:40,
    originDivHeight:40,
    originWidth:6,
    originHeight:6,
    smallLoading:false,
    loadingMaskBg:'rgba(0,0,0,0.2)'
  });
}

// 全局加载时，请先引入sweet-alert.js

var SweetFun = function() {
  return {
    userNameNull: function() {
      swal("用户名为空 !", "请刷新后，重新输入！");
    },
    codeNull: function() {
      swal({
        title: "验证码为空 !",
        text: "请刷新后，重新输入！",
        imageUrl: 'img/warning.png'
      });
    },
    psdIsNull: function() {
      swal({
        title: "密码输入为空 !",
        text: "请刷新后，重新输入！",
        imageUrl: 'img/warning.png'
      });
    },
    twoPsdDiffer: function() {
      swal("密码两次输入不一致 !", "", "error")
    },
    resetPsdSuc: function() {
      swal("重置密码成功！", "", "success")
    },
    PsdSixNum: function() {
      swal("密码输入格式应为6位数字 !", "请刷新后，重新输入！");
    },
    resetPayPsdSuc: function() {
      // swal("重置支付密码成功！", "", "success")
      swal({
        title: "重置支付密码成功！",
        text: "",
        type: "success",
        showCancelButton: true,
        confirmButtonColor: '#DD6B55',
        confirmButtonText: '确认',
        cancelButtonText: "取消",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm){

        if (isConfirm){
          swal("设置成功 !", "你的支付密码已经修改 !", "success", "4000");
          location.href="security.html";
        } else {
          swal("取消", "你已经取消了操作", "error");
        }
      });
    },
    Msg: function() {
      swal({
        title: "emsg...",
        text: "2秒后自动关闭...",
        timer: 2000
      });
    },
    paySuc: function() {
      swal({
        title: "支付成功 !",
        text: "2秒后自动关闭...",
        imageUrl: 'img/right.png',
        timer: 2000
      });
    },
    payPsdSetSuc: function() {
      swal({
        title: "支付密码设置成功 !",
        text: "2秒后自动关闭...",
        imageUrl: 'img/right.png',
        timer: 2000
      });
    },
    PsdError: function() {
      swal({
        title: "两次输入密码不一致 !",
        text: "2秒后自动关闭...",
        imageUrl: 'img/error.png',
        timer: 2000
      });
    },
    NameNotNull: function() {
      swal("姓名不能为空 !", "请刷新后，重新输入！");
    },
    IdNumberNotNull: function() {
      swal("证件号码不能为空 !", "请刷新后，重新输入！");
    },
    UploadIdNumber: function() {
      swal("请上传证件照 !", "请刷新后，重新输入！");
    },
    UploadSuc: function() {
      swal({
        title: "上传成功 !",
        text: "2秒后自动关闭...",
        imageUrl: 'img/right.png',
        timer: 2000
      });
    },
    phoneNumberNull: function() {
      swal({
        title: "手机号为空 !",
        text: "请刷新后，重新输入！",
        imageUrl: 'img/warning.png'
      });
    },
    nickNameNull: function() {
      swal({
        title: "昵称为空 !",
        text: "请刷新后，重新输入！",
        imageUrl: 'img/warning.png'
      });
    },
    agreeMent: function() {
      swal({
        title: "请仔细阅读并同意协议 !",
        text: "请勾选用户协议",
        imageUrl: 'img/warning.png'
      });
    },
    payAgainSetSuc: function() {
      swal({
        title: "支付密码重新设置成功 !",
        text: "2秒后自动关闭...",
        imageUrl: 'img/right.png',
        timer: 2000
      });
    },
  }
};
var SweetFunObj = new SweetFun();
